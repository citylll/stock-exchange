module.exports = {
	devServer: {
		port:8081,
		//disabledHostCheck:true,
	    proxy: {
	      '/api': {
	        target: 'https://admin.bithumb.pw/api',
			changeOrigin:true,
	        pathRewrite: {
	          '^/api': ''
	        }
	      }
	    },
	}
}
