<template>
	<view class="container dark">
		<!--导航-->
		<u-navbar :border-bottom="false" :is-back="false" :background="{'background':'var(--tabbar-color)'}">
			<view class="slot-wrap bg-theme darkStyle">
				<view class="left" @click="leftMenu"></view>
				<view class="center">
					<span class="home-title">{{webConf.name}}</span>
				</view>
				<view class="right" @click="$u.route('/pages/settings/language/language')"></view>
			</view>
		</u-navbar>

		<view class="index-content-wrap">
			<view class="top-wrap-container">
				<!--轮播-->
				<view class="swiper-wrap">
					<home-swiper :list="bannerArr"></home-swiper>
				</view>

				<!--消息公告-->
				<view class="announce-wrap bg-theme" v-if="noticeList.length>0">
					<view class="v-exnoticebar-contianer darkStyle">
						<view class="notice-icon">
							<image class="notice-icon-image" src="@/static/images/common/speak.png" mode="widthFix">
							</image>
						</view>
						<view class="notice-content">
							<swiper class="swiper" autoplay vertical>
								<swiper-item v-for="(item,index) in noticeList" :key="index">
									<view class="swiper-item">
										<view>{{item.title}}</view>
									</view>
								</swiper-item>
							</swiper>
						</view>
						<view class="more" @click="$u.route('/pages/notice/index')">{{$t('index.more')}}</view>
					</view>
				</view>
				<!-- <view style="padding: 0px 30rpx;">
					<span style="color:red;font-size:15px" >
							<marquee>
					            <a class="notice_a ft12" style="color:red;font-size:15px" href="https://t.me/"> </a></marquee>
					</span>
				</view> -->
				<!--行情-->
				<view class="rank-wrap">
					<currency-rank :list="top3"></currency-rank>
				</view>
				<!--快捷入口-->
				<!-- <view style="padding: 0px 30rpx;">
					<home-content></home-content>
				</view> -->
				<view class="assets-top-head1">
					<view class="account-total">
						<image src="@/static/images/common/home-credit.png" style="position: absolute;width: 79px; height: 77px;display: block; position: absolute;bottom: 11px; right: 14px;"></image>
						<view class="top">
							<view class="name">
								
						{{$t("assets.index.zzczh")}} 
							</view>
							<view class="hide-icon">
								<u-icon :name='encrypt ? "eye-off" : "eye"' size="30" @click="encryptText"></u-icon>
							</view>
						</view>
						<view class="bottom">
							<view class="money">{{getContext(totalConvert)}} </view>
							<view class="" v-if="!encrypt">
								{{pricingCurrency.toUpperCase()}}
							</view>
						</view>
						
					</view>
				</view>
				<view class="options-wrap">
					<view class="navbar-wrap">
<!-- 						<view class="nav-content-list">
							<view class="nav-item" @click.stop="$u.route(path.deposit)">
								<image src="@/static/images/common/chongzhi.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.zhinenglicai')}}</view>
							</view>
							<view class="nav-item" @click="$u.route('/pages/lever/index')">
								<image src="@/static/images/common/miaoheyue.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('option.detail.qiquan')}}</view>
							</view>
							<view class="nav-item" @click="$u.route('/pages/publication/index')">
								<image src="@/static/images/common/shengou1.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.faxing')}}</view>
							</view>
							<view class="nav-item" @click="$u.route('/pages/promotion/index')">
								<image src="@/static/images/common/xiangshou.png" class="nav-item-image"
									mode="widthFix"></image>
								 <view class="nav-item-text">{{$t('index.fenxiang')}}</view> 
							</view>		
							<view class="nav-item" @click="$u.route('/pages/help/center/center')">
								<image src="@/static/images/common/suocang.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.bangzhu')}}</view>
							</view>
								
				<view class="nav-item" @click="$u.route('/pages/help/center/center')">
					<image src="@/static/images/common/icon_chat_dark.png" class="nav-item-image"
						mode="widthFix"></image>
					<view class="nav-item-text">{{$t('index.bangzhu')}}</view>
				</view> 
						</view> -->
						<view class="nav-content-list">
							<view class="nav-item" @click.stop="$u.route('/pages/assets/tradeAccount?type=2&id=3')">
								<image src="@/static/images/common/home-zb.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.zhangbianjilu')}}</view>
							</view>
							<navigator class="nav-item" url="/pages/option/detail" hover-class="none" open-type="switchTab">
								<image src="@/static/images/common/home-jy.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.heyuejiaoyi')}}</view>
							</navigator>
							<view class="nav-item" @click.stop="$u.route('/pages/assets/transfer/index?form_type=change&type=2')">
								<image src="@/static/images/common/home-jh.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.kuaisushandui')}}</view>
							</view>
							<navigator class="nav-item" url="/pages/template/index" hover-class="none" open-type="switchTab">
								<image src="@/static/images/common/home-kc.png" class="nav-item-image"
									mode="widthFix"></image>
								 <view class="nav-item-text">{{$t('index.ailicai')}}</view> 
							</navigator>		
						</view>
						<view class="nav-content-list">
							<view class="nav-item" @click.stop="$u.route('/pages/publication/index')">
								<image src="@/static/images/common/newfund.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.jijin')}}</view>
							</view>
							<view class="nav-item" @click="$u.route('/pages/promotion/index')">
								<image src="@/static/images/common/home-myteam.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.wodetuandui')}}</view>
							</view>
							<view class="nav-item" @click="$u.route('/pages/settings/language/language')">
								<image src="@/static/images/common/home-lang.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.xuanzeyuyan')}}</view>
							</view>
							<view class="nav-item" @click="$u.route('/pages/help/center/center')">
								<image src="@/static/images/common/hone-kf.png" class="nav-item-image"
									mode="widthFix"></image>
								<view class="nav-item-text">{{$t('index.bangzhu')}}</view>
							</view>
						</view>
					</view>
				</view>
				<view class="trade-tool">
					<view class="title">
						{{$t('index.huobijiaoyi')}}
					</view>
					<view class="trade-tool-list">
						<view class="item"  @click.stop="$u.route('/pages/assets/deposit/index')">
							<view class="left">
								<view class="name">
									{{$t('index.kuaisuchuzhi')}}
								</view>
								<view class="desc">
									{{$t('index.kuaisuchuzhidesc')}}
								</view>
							</view>
							<image src="@/static/images/common/recharge_bg.png" style="width: 124rpx;height: 122rpx;"></image>
						</view>
						<view class="item"  @click.stop="$u.route('/pages/assets/withdraw/index')">
							<view class="left">
								<view class="name">
									{{$t('index.kuaijietiling')}}
								</view>
								<view class="desc">
									{{$t('index.kuaijietilingdesc')}}
								</view>
							</view>
							<image src="@/static/images/common/withdraw_bg.png" style="width: 114rpx;height: 134rpx;"></image>
						</view>
					</view>
				</view>
				<!--涨幅榜-->
				<view class="list-wrap darkStyle">
					<view class="list-tabs-wrap">
						<ex-title :title="$t('index.zhangfubang')"></ex-title>
					</view>
					<view class="list-content-wrap">
						<v-extables :list="rankArr"></v-extables>
					</view>
				</view>
			</view>


		</view>

		<!--左边弹出层-->
		<left-collapse ref="leftMenuPanel"></left-collapse>

		<!--底部导航-->
		<lw-tabbar :current="0"></lw-tabbar>

		<uni-popup ref="popup" type="center" background-color="rgba(27, 44, 66, 1)">
			<div class="popup">
				<span>{{ noticeTitle }}</span>
				<div class="info">{{ noticeContent }}</div>
			</div>
		</uni-popup>
	</view>
</template>

<script>
	export default {
		onPullDownRefresh: function() {
			this.refresh()
		},
		data() {
			return {
				pageStatus: 'show',
				timer: null,
				top3: [],
				rankArr: [],
				bannerArr: [],
				noticeList: [],
				path: {
					deposit: '/pages/assets/deposit/index',
					withdraw: '/pages/assets/withdraw/index',
					service: this.webConf.serviceChat
				},
				noticeTitle: '',
				noticeContent: '',
				encrypt: !1,
				list: [{
					name: 'assets.index.bbac',
					typename: 'change',
					type: 2,
					active: 0,
					balance: [],
					usdt_totle: 0
				}, {
					name: 'assets.index.hyac',
					typename: 'lever',
					type: 3,
					active: 1,
					balance: [],
					usdt_totle: 0
				}, {
					name: 'assets.index.qqac',
					typename: 'micro',
					type: 4,
					active: 2,
					balance: [],
					usdt_totle: 0
				}],
				pricingCurrency: "usd",
			}
		},
		computed:{
			totalAmount: function() {
				let total = 0
			
				this.list.forEach(item => {
					total += item.usdt_totle
				})
			
				return (total).toFixed(4)
			},
			totalConvert: function() {
				//转换usdt到usd(本地化货币)
				return this.totalAmount
			},
		},
		methods: {
			goLicai: function() {
				uni.switchTab({
					url: '/pages/template/index'
				})
			},
			getRank: async function() { //获取行情
				if (this.pageStatus != 'show') {
					clearTimeout(this.timer)
					return //页面隐藏时不请求
				}
				let res = await this.$u.api.getRank().catch(err => {})

				let tmp = []
				res[0].quotation.forEach(item => {
					if (item.is_display == 1 && item.open_coin_trade == 1) { //只需要币币交易
						tmp.push(item)
					}
				})
				this.rankArr = tmp
				this.top3 = tmp.slice(0, 3) //前三数据

				this.timer = setTimeout(() => {
					this.getRank()
				}, 2000)
			},
			leftMenu: function() {
				this.$refs['leftMenuPanel'].panel('show')
			},
			refresh: async function() { //刷新数据
				this.$refs['leftMenuPanel'] && this.$refs['leftMenuPanel'].getUserInfo() //刷新用户信息
				await this.getRank()
				setTimeout(() => {
					uni.stopPullDownRefresh()
				}, 1000)
			},
			getBanner: function() {
				
				// this.$u.popup.open()
				console.log([this.$u])

				//获取notice广告
				this.$u.api.getNews({
					c_id: 4,
					lang: uni.getStorageSync('lang') || 'en'
				}).then(res => {
					this.noticeList = res.list
				}).catch(err => {})

				//获取banner广告
				this.$u.api.getNews({
					c_id: 5,
					lang: uni.getStorageSync('lang') || 'en'
				}).then(res => {
					//console.log(res)
					let arr = []
					res.list.forEach(item => {
						arr.push(item.cover)
					})
					this.bannerArr = arr
				}).catch(err => {})
			},
			fetchData: async function() {
				var t = this;
				let params = {
					currency_name: ''
				}
			
				const rankData = await this.$u.api.getRank().catch(err => {})
				const {
					quotation
				} = rankData[0]
				console.log('quotation', quotation);
			
				this.$u.api.walletList(params).then(res => {
					uni.stopPullDownRefresh()
			
					console.log('res', res);
			
					const {
						change_wallet,
						lever_wallet,
						micro_wallet
					} = res
			
					//币币
					let bibi = []
					let usdt_totle1 = 0
					if (change_wallet && change_wallet.balance) {
						change_wallet.balance.forEach(item => {
							if (item.is_match == 1) {
								const finded = quotation.find(element => element
									.currency_id === item.currency)
								console.log('finded', finded);
								item.usdt_price = finded ? finded.now_price : item
									.usdt_price
								bibi.push(item)
			
								usdt_totle1 += (item[this.list[0].typename + '_balance'] ? item[this
									.list[0].typename + '_balance'] * 1 : 0) * (item.usdt_price ?
									item.usdt_price * 1 : 0)
							}
						})
					}
					this.list[0].balance = bibi
					this.list[0].usdt_totle = usdt_totle1
			
					//合约
					let heyue = []
					let usdt_totle2 = 0
					if (lever_wallet && lever_wallet.balance) {
						lever_wallet.balance.forEach(item => {
							if (item.is_lever == 1) {
								const finded = quotation.find(element => element
									.currency_id === item.currency)
								console.log('finded', finded);
								item.usdt_price = finded ? finded.now_price : item
									.usdt_price
								heyue.push(item)
			
								usdt_totle2 += (item[this.list[1].typename + '_balance'] ? item[this
									.list[1].typename + '_balance'] * 1 : 0) * (item.usdt_price ?
									item.usdt_price * 1 : 0)
							}
						})
					}
					this.list[1].balance = heyue
					this.list[1].usdt_totle = usdt_totle2
			
					//期权
					let qiquan = []
					let usdt_totle3 = 0
					if (micro_wallet && micro_wallet.balance) {
						micro_wallet.balance.forEach(item => {
							if (item.is_micro == 1) {
								const finded = quotation.find(element => element
									.currency_id === item.currency)
								console.log('finded', finded);
								item.usdt_price = finded ? finded.now_price : item
									.usdt_price
								qiquan.push(item)
			
								usdt_totle3 += (item[this.list[2].typename + '_balance'] ? item[this
									.list[2].typename + '_balance'] * 1 : 0) * (item.usdt_price ?
									item.usdt_price * 1 : 0)
							}
						})
						console.log('usdt_totle3', usdt_totle3);
					}
					this.list[2].balance = qiquan
					this.list[2].usdt_totle = usdt_totle3
			
				}).catch(err => {})
			},
			encryptText: function() {
				this.encrypt = !this.encrypt,
					this.$forceUpdate()
			},
			getContext: function(t) { //隐藏数字
				if (!this.encrypt)
					return t;
				"string" != typeof t && (t = "" + t);
				var e = t.split("").length;
				return "*".repeat(e)
			},

		},
		
		mounted: function () {
			
			let timer = setInterval(()=>{
				if(this.vuex_token){
					this.fetchData();
					clearInterval(timer)
				}
			},1000)
			this.$u.api.getNotice().then(res => {
				console.log('res', res);
				this.noticeTitle = res.recommend_title
				this.noticeContent = res.recommend_content
				if (this.noticeTitle && this.noticeContent) {
					this.$refs.popup.open()
				}
			}).catch(err => {})
			
		},
		
		onLoad: function(){
			this.getBanner()
			this.fetchData()
			var t = this,
				e = uni.getStorageSync("pricingMethod");
			e && (e = JSON.parse(e),
					this.pricingCurrency = e.code.toLowerCase()),
				this.show || (this.loading = !0,
					Promise.all([this.fetchData()]).then((function(e) {
						t.loading = !1
					})).catch((function(e) {
						t.loading = !1
					})))
			uni.$once('langChange', (lang) => {
				//console.log('语言切换',lang)
				this.getBanner()
			})

		},
		onHide: function() {
			this.pageStatus = 'hide'
			this.$refs['leftMenuPanel'] && this.$refs['leftMenuPanel'].panel('hide')
			clearTimeout(this.timer)
		},
		onShow: function() {
			this.pageStatus = 'show'
			this.refresh()
		},
		beforeDestroy: function() {
			clearTimeout(this.timer)
	
	}
}
</script>

<style lang="scss" scoped>
	.popup {
		padding: 30px 20px;
		width: 358px;
		background: #202020;
		border-radius: 7px;
		box-sizing: border-box;
		overflow: hidden;
		display: flex;
		flex-direction: column;
		align-items: center;

		span {
			width: 100%;
			font-size: 18px;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FFFFFF;
			display: flex;
			justify-content: center;
		}

		.info {
			width: 100%;
			font-size: 15px;
			font-family: PingFang SC;
			font-weight: 400;
			color: #2BA693;
			line-height: 19px;
			display: flex;
			justify-content: center;
			margin-top: 22px;
		}

		.btn {
			width: 177px;
			height: 48px;
			background: #2BA693;
			border-radius: 6px;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 18px;
			font-family: PingFang SC;
			font-weight: 400;
			color: #FFFFFF;
			margin-top: 22px;
		}
	}
	.trade-tool{
		padding: 30rpx;
		.title{
			color: #fff;
			font-weight: 400;
			font-size: 48rpx;
		}
		.trade-tool-list{
			margin: 30px 0;
			display: flex;
			.item{
				// height: 82px;
				padding-top: 9px;
				padding-bottom: 6px;
				padding-right: 5px;
				padding-left: 15px;
				box-sizing: border-box;
				border: 1px solid #181818;
				flex-grow: 1;
				display: flex;
				border-radius: 12px;
				.left{
					margin-right: 10px;
					
					.name{
						color: #fff;
						font-size: 16px;
						
						overflow: hidden;
						text-overflow: ellipsis;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
					}
					.desc{
						color: #707a8a;
						font-size: 10px;
						font-family: Arial;
						overflow: hidden;
						text-overflow: ellipsis;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 2;
					}
				}
				image{
					flex-shrink: 0;
				}
				&:first-child{
					margin-right: 20rpx;
				}
			}
		}
	}
	.assets-top-head1{
		position: relative;
		background-color: #000 !important;
		border-radius: 12px;
		padding-top: 14px;
		padding-bottom: 14px;
		padding-left: 15px;
		border: 1px solid #181818;
		width: 690rpx;
		margin: 0 auto;
		box-sizing: border-box;
		margin-bottom: 60rpx;
		.top{
			display: flex;
			align-items: center;
			.name{
				margin-top: 20rpx;
				margin-bottom: 20rpx;
			}
			.hide-icon{
				margin-left: 20rpx;
				
			}
		}
		.bottom{
			color: #707a8a;
			font-size: 30rpx;
			display: flex;
			align-items: flex-end;
			.money{
				font-weight: 500;
				font-size: 48rpx;
				color: #fff;
				margin-right: 20rpx;
			}
		}
	}
</style>

<style scoped>
	>>>.u-slot-content {
		height: 100% !important;
	}

	.slot-wrap {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 100%;
		padding: 0 30rpx;
	}

	.slot-wrap .left {
		width: 50rpx;
		height: 50rpx;
		background: url('@/static/images/common/user-default.png');
		background-size: 100% 100%;
	}

	.slot-wrap .center {
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.slot-wrap.darkStyle .home-title {
		color: #e2e8e4 !important;
	}

	.slot-wrap .center .home-title {
		color: var(--text-color);
		font-family: DIN-Regular-2;
		font-size: 38rpx;
		font-weight: 700;
		letter-spacing: 8rpx;
	}

	.slot-wrap .right {
		width: 40rpx;
		height: 40rpx;
		background: url('@/static/images/common/changelang.png') no-repeat;
		background-size: 40rpx 40rpx; 
	}

	.slot-wrap.darkStyle .right {
		width: 40rpx;
		height: 40rpx;
	}

	/*轮播*/
	.container .index-content-wrap {
		z-index: 100;
	}

	.container .index-content-wrap .top-wrap-container {
		padding-top: 40rpx;
	}

	.container .index-content-wrap .announce-wrap {
		margin: 20rpx 30rpx 0 30rpx;
		border-radius: 20rpx;
	}

	/*消息公告*/
	.v-exnoticebar-contianer {
		display: flex;
		justify-content: space-between;
		padding: 0 30rpx;
		background: var(--page-part-color);
	}

	.v-exnoticebar-contianer .notice-icon {
		margin-right: 14rpx;
		display: flex;
		align-items: center;
	}

	.v-exnoticebar-contianer .notice-icon .notice-icon-image {
		width: 40rpx;
	}

	.v-exnoticebar-contianer .notice-content {
		font-size: 24rpx;
		width: 100%;
		height: 88rpx;
		overflow: hidden;
		font-size: 22rpx;
		line-height: 88rpx;
	}

	.v-exnoticebar-contianer .notice-content .swiper-item {
		color: var(--text-color);
		font-size: 24rpx !important;
	}

	.v-exnoticebar-contianer .more {
		flex: 0 0 auto;
		font-size: 24rpx;
		display: flex;
		align-items: center;
		color: #f8c71b;
		padding: 0 10rpx;
	}

	/*快捷按钮*/
	.container .index-content-wrap .options-wrap {
		margin: 30rpx 30rpx;
	}

	.container .index-content-wrap .options-wrap .navbar-wrap {
		margin-top: 30rpx;
	}

	.container .index-content-wrap .options-wrap .navbar-wrap .nav-content-list {		
		display: flex;
		justify-content: space-between;
		flex-flow: row nowrap;
		margin-bottom: 40rpx;
	}

	.container .index-content-wrap .options-wrap .navbar-wrap .nav-content-list .nav-item {
		flex: 1 0 25%;
		text-align: center;
	}

	.container .index-content-wrap .options-wrap .navbar-wrap .nav-content-list .nav-item .nav-item-image {
		width: 56rpx;
		height: 56rpx;
	}

	.container .index-content-wrap .options-wrap .navbar-wrap .nav-content-list .nav-item .nav-item-text {
		text-align: center;
		margin-top: 24rpx;
	}

	/*涨幅榜*/
	.container .index-content-wrap .list-wrap {
		z-index: 10;
	}

	.container .index-content-wrap .list-wrap.darkStyle {
		/* background: url('@/static/images/common/dark-bg-setting.png') no-repeat; */
		background-size: 100% 100%;
		background-size: cover;
		background-attachment: fixed;
	}
</style>
