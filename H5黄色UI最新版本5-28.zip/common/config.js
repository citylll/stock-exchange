let configData = {}
const NODE_ENV = 'test'; // dev:开发环境 | test:测试环境  
if (process.env.NODE_ENV === "development") {
	console.log('本地环境') 			//本地环境
	configData = {
		apiServer: 'https://vip.bithumb.pw/api'	//基础API地址（只修改前面的域名部分 注意是http还是https）
	}
} else {
	if (NODE_ENV === 'test') {//测试环境
		console.log('测试环境')
		configData = {
			apiServer: 'https://vip.bithumb.pw/api'	//基础API地址（只修改前面的域名部分 注意是http还是https）
		}
	}else{//生产环境
		//console.log('生产环境')
		configData = {
			apiServer: 'https://vip.bithumb.pw'//基础API地址（只修改前面的域名部分 注意是http还是https）
		}
	}
}
configData.staticUrl = 'https://vip.bithumb.pw'	//staticURL 静态资源URL(注意后面没有反斜线)

configData.name = 'Bithumb'	//项目名称
configData.version = '3.5.8'	//版本号

//tg链接
configData.serviceLink = ''	
//内部在线客服
configData.serviceChat = ''	
//内部在线客服打开方式 self=当前窗口内嵌   blank=手机默认浏览器中打开(用于在线客服链接无法内嵌情况)
configData.serviceChatOpenType = 'blank' 

//以下不要动！不要动！不要动！
configData.langList = [
	{title:'English',value:'en'},
	{title:'日本',value:'jp'},
	{title:'한국인',value:'kr'},
	{title:'España',value:'esp'},
	{title:'中文',value:'zh'},
	{title:'繁體中文(臺灣)',value:'hk'},
	{title:'ไทย',value:'th'}
]

configData.netType = {
	'USDT':['TRC20','OMNI','ERC20'],
	'BTC':['OMNI'],
	'ETH':['ERC20']
}

configData.baseCoin = [
	{name:'USDT',currency_id:3,image:"/static/images/common/USDT.png"},
	{name:'ETH',currency_id:2,image:"/static/images/common/ETH.png"},
	{name:'BTC',currency_id:1,image:"/static/images/common/BTC.png"},
	{name:'Bank',currency_id:9999,image:"/static/images/common/MAX.png"}
]

export default configData